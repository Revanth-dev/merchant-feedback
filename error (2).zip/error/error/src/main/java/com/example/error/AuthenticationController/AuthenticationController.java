package com.example.error.AuthenticationController;

import com.example.error.AuthenticationService.AuthenticationService;
import com.example.error.Employee.Employee;
import com.example.error.dto.LoginRequest;
import com.example.error.dto.LoginResponse; // Import the new LoginResponse class
import com.example.error.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthenticationController {

    @Autowired
    private AuthenticationService authenticationService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/signup")
    public ResponseEntity<String> signUp(@RequestBody Employee employee) {
        try {
            authenticationService.register(employee);
            return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Registration failed: " + e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
        LoginResponse employee = authenticationService.login(loginRequest.getEmail(), loginRequest.getPassword());
        if (employee != null) {
            String token = jwtUtil.generateToken(employee.getEmail());
            LoginResponse loginResponse = new LoginResponse(token, employee.getEmail());
            return ResponseEntity.ok(loginResponse); // Return LoginResponse instead of Employee
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null); // Return null or an error message for unauthorized
        }
    }
}