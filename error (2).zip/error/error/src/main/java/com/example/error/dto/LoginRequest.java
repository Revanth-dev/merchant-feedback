package com.example.error.dto;

public class LoginRequest {
    private String email;
    private String password;
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

    // Getters and Setters
}