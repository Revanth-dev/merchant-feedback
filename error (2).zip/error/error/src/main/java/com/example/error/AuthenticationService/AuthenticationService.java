package com.example.error.AuthenticationService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.error.Employee.Employee;
import com.example.error.EmployeeRepository.EmployeeRepository;
import com.example.error.dto.LoginResponse; // Import LoginResponse DTO
//import com.example.error.service.JwtService; // Import JwtService

@Service
public class AuthenticationService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private JwtService jwtService; // Inject JwtService

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public Employee register(Employee employee) {
        // Hash the password before saving
        employee.setPassword(passwordEncoder.encode(employee.getPassword()));
        return employeeRepository.save(employee);
    }

    public LoginResponse login(String email, String password) {
        Employee employee = employeeRepository.findByEmail(email);
        if (employee != null && passwordEncoder.matches(password, employee.getPassword())) {
            // Generate JWT token upon successful login
            String token = jwtService.generateToken(employee.getEmail());
            return new LoginResponse("Login successful", token); // Return token with success message
        }
        return null; // Authentication failed
    }

    public Employee getUserByEmail(String email) {
        // Retrieve employee by email
        return employeeRepository.findByEmail(email);
    }

    public List<Employee> getAllUsers() {
        // Retrieve all employees
        return employeeRepository.findAll();
    }
}