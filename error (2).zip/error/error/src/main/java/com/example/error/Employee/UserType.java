package com.example.error.Employee;



public enum UserType {
    ADMIN,
    USER,
    GUEST
   
}